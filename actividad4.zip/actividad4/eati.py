import sys

def main():
    par1 = sys.argv[1]
    par2 = sys.argv[2]

    print(par1, ' ', par2)

if __name__ == "__main__":
    main()